module.exports = require("nativescript-dev-android-snapshot/hooks/before-prepare-hook.js");
