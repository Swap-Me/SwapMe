module.exports = require("nativescript-dev-typescript/lib/before-prepare.js");
