"use strict";
var Emoji = (function () {
    function Emoji() {
    }
    return Emoji;
}());
exports.Emoji = Emoji;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW1vamkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJlbW9qaS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7SUFBQTtJQUdBLENBQUM7SUFBRCxZQUFDO0FBQUQsQ0FBQyxBQUhELElBR0M7QUFIWSxzQkFBSyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBFbW9qaSB7XHJcbiAgICBjb2RlOiBzdHJpbmc7XHJcbiAgICBjb2xvcjogc3RyaW5nO1xyXG59XHJcbiJdfQ==