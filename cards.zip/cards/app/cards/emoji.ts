export class Emoji {
    code: string;
    color: string;
}
