"use strict";
var core_1 = require("@angular/core");
var gestures_1 = require("ui/gestures");
var grid_layout_1 = require("ui/layouts/grid-layout");
var label_1 = require("ui/label");
var card_service_1 = require("./card.service");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var CardComponent = (function () {
    function CardComponent(cardService, fonticon) {
        this.cardService = cardService;
        this.fonticon = fonticon;
        this.i = 0;
    }
    CardComponent.prototype.ngOnInit = function () {
        this.emoji = this.cardService.getEmoji();
        //initial card
        this.code = this.emoji[this.i].code;
        //get ready for the swiping!
        for (var key in this.emoji) {
            this.handleSwipe(key);
        }
    };
    CardComponent.prototype.handleSwipe = function (key) {
        this.i--;
        var grid = new grid_layout_1.GridLayout();
        var emoji = new label_1.Label();
        var yes = this.yes.nativeElement;
        var no = this.no.nativeElement;
        var absolutelayout = this.al.nativeElement;
        var swipeleft = this.swipeleft.nativeElement;
        var swiperight = this.swiperight.nativeElement;
        //set the emoji on the card
        emoji.text = this.emoji[key].code;
        //android specific
        emoji.verticalAlignment = "center";
        //build the grid which is the card
        grid.cssClass = 'card ' + this.emoji[key].color;
        grid.id = 'card' + Number(key);
        grid.marginTop = this.i;
        //add the emoji to the grid, and the grid to the absolutelayout
        grid.addChild(emoji);
        absolutelayout.addChild(grid);
        //handle tapping
        /*swiperight.addEventListener("tap", function(){
            //animate yes
        });

        swipeleft.addEventListener("tap", function(){
            //animate no
        })*/
        //make card swipable
        grid.on(gestures_1.GestureTypes.swipe, function (args) {
            if (args.direction == 1) {
                //right
                yes.animate({ opacity: 0, duration: 100 })
                    .then(function () { return yes.animate({ opacity: 1, duration: 100 }); })
                    .then(function () { return yes.animate({ opacity: 0, duration: 100 }); })
                    .then(function () {
                    return grid.animate({ translate: { x: 1000, y: 100 } })
                        .then(function () { return grid.animate({ translate: { x: 0, y: -2000 } }); })
                        .catch(function (e) {
                        console.log(e.message);
                    });
                })
                    .catch(function (e) {
                    console.log(e.message);
                });
            }
            else {
                //left
                no.animate({ opacity: 0, duration: 100 })
                    .then(function () { return no.animate({ opacity: 1, duration: 100 }); })
                    .then(function () { return no.animate({ opacity: 0, duration: 100 }); })
                    .then(function () {
                    return grid.animate({ translate: { x: -1000, y: 100 } })
                        .then(function () { return grid.animate({ translate: { x: 0, y: -2000 } }); })
                        .catch(function (e) {
                        console.log(e.message);
                    });
                })
                    .catch(function (e) {
                    console.log(e.message);
                });
            }
        });
    };
    return CardComponent;
}());
__decorate([
    core_1.ViewChild("absolutelayout"),
    __metadata("design:type", core_1.ElementRef)
], CardComponent.prototype, "al", void 0);
__decorate([
    core_1.ViewChild("yes"),
    __metadata("design:type", core_1.ElementRef)
], CardComponent.prototype, "yes", void 0);
__decorate([
    core_1.ViewChild("no"),
    __metadata("design:type", core_1.ElementRef)
], CardComponent.prototype, "no", void 0);
__decorate([
    core_1.ViewChild("swipeleft"),
    __metadata("design:type", core_1.ElementRef)
], CardComponent.prototype, "swipeleft", void 0);
__decorate([
    core_1.ViewChild("swiperight"),
    __metadata("design:type", core_1.ElementRef)
], CardComponent.prototype, "swiperight", void 0);
CardComponent = __decorate([
    core_1.Component({
        moduleId: module.id,
        templateUrl: "./card.component.html"
    }),
    __metadata("design:paramtypes", [card_service_1.CardService,
        nativescript_ngx_fonticon_1.TNSFontIconService])
], CardComponent);
exports.CardComponent = CardComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FyZC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJjYXJkLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQXlFO0FBQ3pFLHdDQUFvRjtBQUNwRixzREFBb0Q7QUFFcEQsa0NBQWlDO0FBRWpDLCtDQUE2QztBQUU3Qyx1RUFBK0Q7QUFNL0QsSUFBYSxhQUFhO0lBRXRCLHVCQUNZLFdBQXdCLEVBQ3hCLFFBQTRCO1FBRDVCLGdCQUFXLEdBQVgsV0FBVyxDQUFhO1FBQ3hCLGFBQVEsR0FBUixRQUFRLENBQW9CO1FBS3hDLE1BQUMsR0FBVyxDQUFDLENBQUM7SUFKVixDQUFDO0lBWUwsZ0NBQVEsR0FBUjtRQUNJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUN6QyxjQUFjO1FBQ2QsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDcEMsNEJBQTRCO1FBQzVCLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBQ3pCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDMUIsQ0FBQztJQUNMLENBQUM7SUFFRCxtQ0FBVyxHQUFYLFVBQVksR0FBUTtRQUVoQixJQUFJLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFFVCxJQUFJLElBQUksR0FBRyxJQUFJLHdCQUFVLEVBQUUsQ0FBQztRQUM1QixJQUFJLEtBQUssR0FBRyxJQUFJLGFBQUssRUFBRSxDQUFDO1FBRXhCLElBQUksR0FBRyxHQUFVLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ3hDLElBQUksRUFBRSxHQUFVLElBQUksQ0FBQyxFQUFFLENBQUMsYUFBYSxDQUFDO1FBQ3RDLElBQUksY0FBYyxHQUFtQixJQUFJLENBQUMsRUFBRSxDQUFDLGFBQWEsQ0FBQztRQUMzRCxJQUFJLFNBQVMsR0FBVyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQztRQUNyRCxJQUFJLFVBQVUsR0FBVyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQztRQUV2RCwyQkFBMkI7UUFDM0IsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNsQyxrQkFBa0I7UUFDbEIsS0FBSyxDQUFDLGlCQUFpQixHQUFHLFFBQVEsQ0FBQztRQUVuQyxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDaEQsSUFBSSxDQUFDLEVBQUUsR0FBRyxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUV4QiwrREFBK0Q7UUFDL0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNyQixjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO1FBRTdCLGdCQUFnQjtRQUNoQjs7Ozs7O1lBTUk7UUFFSixvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLEVBQUUsQ0FBQyx1QkFBWSxDQUFDLEtBQUssRUFBRSxVQUFVLElBQTJCO1lBQzdELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDdEIsT0FBTztnQkFDUCxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFFLENBQUM7cUJBQ3JDLElBQUksQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQTFDLENBQTBDLENBQUM7cUJBQ3RELElBQUksQ0FBQyxjQUFNLE9BQUEsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQTFDLENBQTBDLENBQUM7cUJBQ3RELElBQUksQ0FBQztvQkFDRixPQUFBLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDO3lCQUMzQyxJQUFJLENBQUMsY0FBYyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM3RSxLQUFLLENBQUMsVUFBVSxDQUFDO3dCQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMzQixDQUFDLENBQUM7Z0JBSk4sQ0FJTSxDQUNUO3FCQUNBLEtBQUssQ0FBQyxVQUFDLENBQUM7b0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzNCLENBQUMsQ0FBQyxDQUFDO1lBQ1gsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNGLE1BQU07Z0JBQ04sRUFBRSxDQUFDLE9BQU8sQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBRSxDQUFDO3FCQUNwQyxJQUFJLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUF6QyxDQUF5QyxDQUFDO3FCQUNyRCxJQUFJLENBQUMsY0FBTSxPQUFBLEVBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUF6QyxDQUF5QyxDQUFDO3FCQUNyRCxJQUFJLENBQUM7b0JBQ0YsT0FBQSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsU0FBUyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLENBQUMsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDO3lCQUM1QyxJQUFJLENBQUMsY0FBYyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM3RSxLQUFLLENBQUMsVUFBVSxDQUFDO3dCQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDO29CQUMzQixDQUFDLENBQUM7Z0JBSk4sQ0FJTSxDQUNUO3FCQUNBLEtBQUssQ0FBQyxVQUFDLENBQUM7b0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzNCLENBQUMsQ0FBQyxDQUFDO1lBQ1gsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVMLG9CQUFDO0FBQUQsQ0FBQyxBQXBHRCxJQW9HQztBQXpGZ0M7SUFBNUIsZ0JBQVMsQ0FBQyxnQkFBZ0IsQ0FBQzs4QkFBSyxpQkFBVTt5Q0FBQztBQUMxQjtJQUFqQixnQkFBUyxDQUFDLEtBQUssQ0FBQzs4QkFBTSxpQkFBVTswQ0FBQztBQUNqQjtJQUFoQixnQkFBUyxDQUFDLElBQUksQ0FBQzs4QkFBSyxpQkFBVTt5Q0FBQztBQUNSO0lBQXZCLGdCQUFTLENBQUMsV0FBVyxDQUFDOzhCQUFZLGlCQUFVO2dEQUFDO0FBQ3JCO0lBQXhCLGdCQUFTLENBQUMsWUFBWSxDQUFDOzhCQUFhLGlCQUFVO2lEQUFDO0FBZnZDLGFBQWE7SUFKekIsZ0JBQVMsQ0FBQztRQUNQLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtRQUNuQixXQUFXLEVBQUUsdUJBQXVCO0tBQ3ZDLENBQUM7cUNBSTJCLDBCQUFXO1FBQ2QsOENBQWtCO0dBSi9CLGFBQWEsQ0FvR3pCO0FBcEdZLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFZpZXdDaGlsZCwgRWxlbWVudFJlZiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IFN3aXBlR2VzdHVyZUV2ZW50RGF0YSwgR2VzdHVyZXNPYnNlcnZlciwgR2VzdHVyZVR5cGVzIH0gZnJvbSBcInVpL2dlc3R1cmVzXCI7XHJcbmltcG9ydCB7IEdyaWRMYXlvdXQgfSBmcm9tIFwidWkvbGF5b3V0cy9ncmlkLWxheW91dFwiO1xyXG5pbXBvcnQgeyBBYnNvbHV0ZUxheW91dCB9IGZyb20gXCJ1aS9sYXlvdXRzL2Fic29sdXRlLWxheW91dFwiO1xyXG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gXCJ1aS9sYWJlbFwiO1xyXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwidWkvYnV0dG9uXCI7XHJcbmltcG9ydCB7IENhcmRTZXJ2aWNlIH0gZnJvbSAnLi9jYXJkLnNlcnZpY2UnO1xyXG5pbXBvcnQgeyBFbW9qaSB9IGZyb20gJy4vZW1vamknO1xyXG5pbXBvcnQgeyBUTlNGb250SWNvblNlcnZpY2UgfSBmcm9tICduYXRpdmVzY3JpcHQtbmd4LWZvbnRpY29uJztcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gICAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICAgIHRlbXBsYXRlVXJsOiBcIi4vY2FyZC5jb21wb25lbnQuaHRtbFwiXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBDYXJkQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwcml2YXRlIGNhcmRTZXJ2aWNlOiBDYXJkU2VydmljZSxcclxuICAgICAgICBwcml2YXRlIGZvbnRpY29uOiBUTlNGb250SWNvblNlcnZpY2VcclxuICAgICkgeyB9XHJcblxyXG4gICAgZW1vamk6IEVtb2ppW107XHJcbiAgICBjb2RlOiBzdHJpbmc7XHJcbiAgICBpOiBudW1iZXIgPSAwO1xyXG5cclxuICAgIEBWaWV3Q2hpbGQoXCJhYnNvbHV0ZWxheW91dFwiKSBhbDogRWxlbWVudFJlZjtcclxuICAgIEBWaWV3Q2hpbGQoXCJ5ZXNcIikgeWVzOiBFbGVtZW50UmVmO1xyXG4gICAgQFZpZXdDaGlsZChcIm5vXCIpIG5vOiBFbGVtZW50UmVmO1xyXG4gICAgQFZpZXdDaGlsZChcInN3aXBlbGVmdFwiKSBzd2lwZWxlZnQ6IEVsZW1lbnRSZWY7XHJcbiAgICBAVmlld0NoaWxkKFwic3dpcGVyaWdodFwiKSBzd2lwZXJpZ2h0OiBFbGVtZW50UmVmO1xyXG5cclxuICAgIG5nT25Jbml0KCkge1xyXG4gICAgICAgIHRoaXMuZW1vamkgPSB0aGlzLmNhcmRTZXJ2aWNlLmdldEVtb2ppKCk7XHJcbiAgICAgICAgLy9pbml0aWFsIGNhcmRcclxuICAgICAgICB0aGlzLmNvZGUgPSB0aGlzLmVtb2ppW3RoaXMuaV0uY29kZTtcclxuICAgICAgICAvL2dldCByZWFkeSBmb3IgdGhlIHN3aXBpbmchXHJcbiAgICAgICAgZm9yICh2YXIga2V5IGluIHRoaXMuZW1vamkpIHtcclxuICAgICAgICAgICAgdGhpcy5oYW5kbGVTd2lwZShrZXkpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBoYW5kbGVTd2lwZShrZXk6IGFueSkge1xyXG5cclxuICAgICAgICB0aGlzLmktLTtcclxuXHJcbiAgICAgICAgbGV0IGdyaWQgPSBuZXcgR3JpZExheW91dCgpO1xyXG4gICAgICAgIGxldCBlbW9qaSA9IG5ldyBMYWJlbCgpO1xyXG5cclxuICAgICAgICBsZXQgeWVzID0gPExhYmVsPnRoaXMueWVzLm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IG5vID0gPExhYmVsPnRoaXMubm8ubmF0aXZlRWxlbWVudDtcclxuICAgICAgICBsZXQgYWJzb2x1dGVsYXlvdXQgPSA8QWJzb2x1dGVMYXlvdXQ+dGhpcy5hbC5uYXRpdmVFbGVtZW50O1xyXG4gICAgICAgIGxldCBzd2lwZWxlZnQgPSA8QnV0dG9uPnRoaXMuc3dpcGVsZWZ0Lm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAgICAgbGV0IHN3aXBlcmlnaHQgPSA8QnV0dG9uPnRoaXMuc3dpcGVyaWdodC5uYXRpdmVFbGVtZW50O1xyXG5cclxuICAgICAgICAvL3NldCB0aGUgZW1vamkgb24gdGhlIGNhcmRcclxuICAgICAgICBlbW9qaS50ZXh0ID0gdGhpcy5lbW9qaVtrZXldLmNvZGU7XHJcbiAgICAgICAgLy9hbmRyb2lkIHNwZWNpZmljXHJcbiAgICAgICAgZW1vamkudmVydGljYWxBbGlnbm1lbnQgPSBcImNlbnRlclwiO1xyXG5cclxuICAgICAgICAvL2J1aWxkIHRoZSBncmlkIHdoaWNoIGlzIHRoZSBjYXJkXHJcbiAgICAgICAgZ3JpZC5jc3NDbGFzcyA9ICdjYXJkICcgKyB0aGlzLmVtb2ppW2tleV0uY29sb3I7XHJcbiAgICAgICAgZ3JpZC5pZCA9ICdjYXJkJyArIE51bWJlcihrZXkpO1xyXG4gICAgICAgIGdyaWQubWFyZ2luVG9wID0gdGhpcy5pO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vYWRkIHRoZSBlbW9qaSB0byB0aGUgZ3JpZCwgYW5kIHRoZSBncmlkIHRvIHRoZSBhYnNvbHV0ZWxheW91dFxyXG4gICAgICAgIGdyaWQuYWRkQ2hpbGQoZW1vamkpO1xyXG4gICAgICAgIGFic29sdXRlbGF5b3V0LmFkZENoaWxkKGdyaWQpXHJcblxyXG4gICAgICAgIC8vaGFuZGxlIHRhcHBpbmdcclxuICAgICAgICAvKnN3aXBlcmlnaHQuYWRkRXZlbnRMaXN0ZW5lcihcInRhcFwiLCBmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAvL2FuaW1hdGUgeWVzXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIHN3aXBlbGVmdC5hZGRFdmVudExpc3RlbmVyKFwidGFwXCIsIGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgIC8vYW5pbWF0ZSBub1xyXG4gICAgICAgIH0pKi9cclxuXHJcbiAgICAgICAgLy9tYWtlIGNhcmQgc3dpcGFibGVcclxuICAgICAgICBncmlkLm9uKEdlc3R1cmVUeXBlcy5zd2lwZSwgZnVuY3Rpb24gKGFyZ3M6IFN3aXBlR2VzdHVyZUV2ZW50RGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoYXJncy5kaXJlY3Rpb24gPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgLy9yaWdodFxyXG4gICAgICAgICAgICAgICAgeWVzLmFuaW1hdGUoeyBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMTAwIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgLnRoZW4oKCkgPT4geWVzLmFuaW1hdGUoeyBvcGFjaXR5OiAxLCBkdXJhdGlvbjogMTAwIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHllcy5hbmltYXRlKHsgb3BhY2l0eTogMCwgZHVyYXRpb246IDEwMCB9KSlcclxuICAgICAgICAgICAgICAgICAgICAudGhlbigoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBncmlkLmFuaW1hdGUoeyB0cmFuc2xhdGU6IHsgeDogMTAwMCwgeTogMTAwIH0gfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGdyaWQuYW5pbWF0ZSh7IHRyYW5zbGF0ZTogeyB4OiAwLCB5OiAtMjAwMCB9IH0pOyB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGVsc2Uge1xyXG4gICAgICAgICAgICAgICAgLy9sZWZ0XHJcbiAgICAgICAgICAgICAgICBuby5hbmltYXRlKHsgb3BhY2l0eTogMCwgZHVyYXRpb246IDEwMCB9KVxyXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IG5vLmFuaW1hdGUoeyBvcGFjaXR5OiAxLCBkdXJhdGlvbjogMTAwIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IG5vLmFuaW1hdGUoeyBvcGFjaXR5OiAwLCBkdXJhdGlvbjogMTAwIH0pKVxyXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGdyaWQuYW5pbWF0ZSh7IHRyYW5zbGF0ZTogeyB4OiAtMTAwMCwgeTogMTAwIH0gfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC50aGVuKGZ1bmN0aW9uICgpIHsgcmV0dXJuIGdyaWQuYW5pbWF0ZSh7IHRyYW5zbGF0ZTogeyB4OiAwLCB5OiAtMjAwMCB9IH0pOyB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLmNhdGNoKGZ1bmN0aW9uIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coZS5tZXNzYWdlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhlLm1lc3NhZ2UpO1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcblxyXG59Il19